const socket = io();
let countryCode = "??";
let countryName = "Unknown";

fetch("https://ipapi.co/json/")
  .then(res => res.json())
  .then(data => {
    countryCode = data.country_code;
    countryName = data.country_name;
    document.getElementById("countryLabel").textContent = `You're clicking for: ${countryName} (${countryCode})`;
    socket.emit("register", countryCode, countryName);
  });

document.getElementById("clickBtn").addEventListener("click", () => {
  socket.emit("click", countryCode);
});

socket.on("update", data => {
  const leaderboard = document.getElementById("leaderboard");
  leaderboard.innerHTML = "";
  const myData = data[countryCode] || { clicks: 0, users: 0 };
  document.getElementById("myClicks").textContent = myData.clicks;
  document.getElementById("userCount").textContent = myData.users;
  const sorted = Object.entries(data).sort((a, b) => b[1].clicks - a[1].clicks);
  sorted.forEach(([code, { name, clicks, users }]) => {
    const li = document.createElement("li");
    li.innerHTML = `<img src="https://flagcdn.com/24x18/${code.toLowerCase()}.png"/> ${name} - ${clicks} clicks (${users} users)`;
    leaderboard.appendChild(li);
  });
});
