const express = require('express');
const http = require('http');
const app = express();
const server = http.createServer(app);
const io = require('socket.io')(server);

let countries = {}; // { US: { name: "United States", clicks: 0, users: 0 }, ... }

app.use(express.static('public'));

io.on('connection', socket => {
  let countryCode = null;

  socket.on('register', (code, name) => {
    countryCode = code;
    if (!countries[code]) {
      countries[code] = { name, clicks: 0, users: 0 };
    }
    countries[code].users += 1;
    io.emit('update', countries);
  });

  socket.on('click', code => {
    if (countries[code]) {
      countries[code].clicks += 1;
      io.emit('update', countries);
    }
  });

  socket.on('disconnect', () => {
    if (countryCode && countries[countryCode]) {
      countries[countryCode].users -= 1;
      if (countries[countryCode].users < 0) countries[countryCode].users = 0;
      io.emit('update', countries);
    }
  });
});

server.listen(3000, () => {
  console.log('Clicker server running on http://localhost:3000');
});
